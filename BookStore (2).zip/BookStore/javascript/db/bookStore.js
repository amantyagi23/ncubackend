const BOOKSTORE =
    {
        "books": [
          {
            "id": 1,
            "title": "The Great Gatsby",
            "author": "F. Scott Fitzgerald",
            "publisher": "Scribner",
            "price": 12.99,
            "coverImage": "https://example.com/book1.jpg"
          },
          {
            "id": 2,
            "title": "To Kill a Mockingbird",
            "author": "Harper Lee",
            "publisher": "HarperCollins",
            "price": 10.99,
            "coverImage": "https://example.com/book2.jpg"
          },
          {
            "id": 3,
            "title": "1984",
            "author": "George Orwell",
            "publisher": "Penguin",
            "price": 9.99,
            "coverImage": "https://example.com/book3.jpg"
          },
          {
            "id": 4,
            "title": "The Catcher in the Rye",
            "author": "J.D. Salinger",
            "publisher": "Little, Brown and Company",
            "price": 11.99,
            "coverImage": "https://example.com/book4.jpg"
          },
          {
            "id": 5,
            "title": "Pride and Prejudice",
            "author": "Jane Austen",
            "publisher": "Penguin Classics",
            "price": 8.99,
            "coverImage": "https://example.com/book5.jpg"
          },
          {
            "id": 6,
            "title": "The Hobbit",
            "author": "J.R.R. Tolkien",
            "publisher": "Houghton Mifflin Harcourt",
            "price": 14.99,
            "coverImage": "https://example.com/book6.jpg"
          },
          {
            "id": 7,
            "title": "The Alchemist",
            "author": "Paulo Coelho",
            "publisher": "HarperOne",
            "price": 13.49,
            "coverImage": "https://example.com/book7.jpg"
          },
          {
            "id": 8,
            "title": "The Lord of the Rings",
            "author": "J.R.R. Tolkien",
            "publisher": "Mariner Books",
            "price": 17.99,
            "coverImage": "https://example.com/book8.jpg"
          },
          {
            "id": 9,
            "title": "Harry Potter and the Sorcerer's Stone",
            "author": "J.K. Rowling",
            "publisher": "Scholastic",
            "price": 15.99,
            "coverImage": "https://example.com/book9.jpg"
          },
          {
            "id": 10,
            "title": "The Hunger Games",
            "author": "Suzanne Collins",
            "publisher": "Scholastic Press",
            "price": 10.49,
            "coverImage": "https://example.com/book10.jpg"
          }
        ]
      }
      

export default BOOKSTORE;