const USERSTORE = {
    "users":[
        {
            "name":"Aman Tyagi",
            "email":"atyagiat3456@gmail.com",
            "password":"123456"
        }
    ]
}


export default USERSTORE;