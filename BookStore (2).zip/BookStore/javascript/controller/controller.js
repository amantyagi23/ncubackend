import BOOKOPERATION from "../services/bookServices.js";
import USEROPERATIONS from "../services/userServices.js";

window.addEventListener('load', bindEvents);

function bindEvents() {
    printBooks();
    
    USEROPERATIONS.getAllUser();
    
}
const loginForm = document.querySelector('#loginForm');
const registerForm = document.querySelector('#registerForm');
const logoutbtn = document.querySelector('.logoutbtn');

logoutbtn.addEventListener(
    'click',
    ()=>{
        if(USEROPERATIONS.isLogin){
            USEROPERATIONS.logoutUser();
            logoutbtn.classList.remove("showLogoutBtn");
            document.querySelector("#payButton").classList.remove("showLogoutBtn")
            alert("Logout Successfully")
        }
        else{
            alert("Please Login")
        }
    }
)

function addToCart(id) {
    if(USEROPERATIONS.isLogin){
        console.log(this.parentNode)
        BOOKOPERATION.addToCartOperation(id);
    alert("Book Added to Cart")
    printCart();
    document.querySelector("#payButton").classList.add("showLogoutBtn")
    }
    else{
        alert("Please Login")
        return;
    }
}

function printBooks() {
    const allbooks = BOOKOPERATION.getAllBook();
    const tbody = document.querySelector('#tbody');
    allbooks.forEach((book) => {
        const tr = document.createElement("tr");

        const imgCell = document.createElement("td");
        const img = document.createElement("img");
        img.src = book.coverImage;
        img.alt = "";
        imgCell.appendChild(img);

        const titleCell = document.createElement("td");
        titleCell.textContent = book.title;

        const authorCell = document.createElement("td");
        authorCell.textContent = book.author;

        const publisherCell = document.createElement("td");
        publisherCell.textContent = book.publisher;

        const priceCell = document.createElement("td");
        priceCell.textContent = book.price + "$";

        const addToCartCell = document.createElement("td");
        const addToCartButton = document.createElement("button");
        addToCartButton.classList.add("addToCartBtn");
        addToCartButton.textContent = "AddToCart";
        addToCartButton.setAttribute("bookId",book.id)
        addToCartButton.addEventListener('click', () => addToCart(book.id));
        addToCartCell.appendChild(addToCartButton);

        tr.appendChild(imgCell);
        tr.appendChild(titleCell);
        tr.appendChild(authorCell);
        tr.appendChild(publisherCell);
        tr.appendChild(priceCell);
        tr.appendChild(addToCartCell);

        tbody.appendChild(tr);
    });
}


function printCart(){
    const allbooks = BOOKOPERATION.getCart();
    const tbody = document.querySelector('#cartTbody');
    let totalAmount = 0;

    if(USEROPERATIONS.isLogin){
        tbody.innerHTML = ''
        allbooks.forEach((book) => {
            const tr = document.createElement("tr");
    
    
            const titleCell = document.createElement("td");
            titleCell.textContent = book.title;
    
            const quantityCell = document.createElement("td");
            quantityCell.textContent = 1;
    
            const priceCell = document.createElement("td");
            priceCell.textContent = book.price + "$";
    
            const amountCell = document.createElement("td");
            amountCell.textContent = (book.price * quantityCell.textContent) + "$"
            totalAmount = totalAmount+ (book.price * quantityCell.textContent);
            tr.appendChild(titleCell);
            tr.appendChild(priceCell);
            tr.appendChild(quantityCell);
            tr.appendChild(amountCell);
            tbody.appendChild(tr);
        });
        document.querySelector("#showAmount").innerHTML = totalAmount + "$";
    }
    else{
        alert("Please Login")
        tbody.innerHTML = "<h1>Please Login</h1>"
        
        return;
    }

}


loginForm.addEventListener('submit', function (event) {
    event.preventDefault();
    const formData = new FormData(loginForm);
    const userObj = {
        "email" :formData.get('username'),
        "password" : formData.get('password')
    }
    loginForm.reset();
    USEROPERATIONS.loginUser(userObj);
    if(USEROPERATIONS.isLogin){
        alert("Login Successfully")
        printCart();
        logoutbtn.classList.add("showLogoutBtn");
        // changeLoginRegister();
    }
    else{
        alert("Invalid Email Or Password")
    }
});

registerForm.addEventListener('submit', function (event) {
    event.preventDefault();
    const formData = new FormData(registerForm);
    if(formData.get("password") === formData.get("confirm-password")){
        const userObj = {
            "name":formData.get("name"),
            "email" :formData.get('email'),
            "password" : formData.get('password')
        }
        USEROPERATIONS.registerUser(userObj);
        alert("Register Successfully")
        registerForm.reset()
    }
});


// this function call is used to change the inner style of login and register page

