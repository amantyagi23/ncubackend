import USERSTORE from "../db/userStore.js";

const USEROPERATIONS = {
    allUsers:[],
    isLogin:false,
    getAllUser(){
        this.allUsers = USERSTORE.users
    },
    registerUser(userObj){
        USERSTORE.users.push(userObj);
        this.getAllUser();
    },
    loginUser(userObj){
        const user = this.allUsers.find((user)=>user.email === userObj.email);
        if(user){
            if(user.password===userObj.password){
                this.isLogin = true;
                return ;
            }
            else{
                return ;
            }
        }
        else{
            return 
        }

    },
    logoutUser(){
        this.isLogin= false;
        return;
    }
}

export default USEROPERATIONS;