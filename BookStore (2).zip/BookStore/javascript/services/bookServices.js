import BOOKSTORE from "../db/bookStore.js"

const BOOKOPERATION = {
    allBook: [],
    bookCart:[],
    getAllBook(){
        this.allBook = BOOKSTORE.books
        return this.allBook;
    },

    getCart(){
        return this.bookCart;
    },

    addToCartOperation(bookId){
        const book = this.allBook.find((item)=>item.id === bookId)
        this.bookCart.push(book);
        return;
    }


}

export default BOOKOPERATION;