class book{
    constructor(){
        
    }

}
export default book;