class user{
    constructor(){
        
    }
}

export default user;