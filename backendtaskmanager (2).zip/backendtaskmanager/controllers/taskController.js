const { response, request } = require("express");
const taskModel = require("../model/taskModel");
const {v4}  = require('uuid');



const createTaskController = async()=>{

    try {
        const uuid = v4();

        const dateOfCreation  = new Date.now().toString();
        const {title,desc,useremail} = request.body;
        const task = await taskModel.create({
            taskId:uuid,
            dateOfCreation:dateOfCreation,
            title:title,
            desc:desc,
            useremail:useremail
        })

        if(task && task._id){
            response.status(201).json({message:"Task Created Successfully"})
        }

        else{
            response.status(404).json({message:"Task Not Created"})
        }
        
    } catch (error) {
        response.status(500).json({message:"Internal Server Error"})
    }

}

const getTaskController = async()=>{

    try {

        const  task = await taskModel.find({});
        
    } catch (error) {
        response.status(500).json({message:"Internal Server Error"})
    }

}

const deleteTaskController = async()=>{

    try {
        const task = await taskModel.deleteOne({title:title})
    } catch (error) {
        response.status(500).json({message:"Internal Server Error"})
    }

}

const updateTaskController = async()=>{

    try {
        const task = await taskModel.updateOne({title:title})
    } catch (error) {
        response.status(500).json({message:"Internal Server Error"})
    }

}




