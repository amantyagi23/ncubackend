const { default: mongoose } = require("mongoose")

const URL = "mongodb+srv://amantyagi4987:admin123@cluster0.iyhsv1d.mongodb.net/taskManagerDatabase?retryWrites=true&w=majority"
const connection = ()=>{
    mongoose.connect(URL).then(()=>{
        console.log("Database Connected Successfully");
    }).catch(()=>{
        console.log("Database Not Connected");
    })
}

module.exports = connection;