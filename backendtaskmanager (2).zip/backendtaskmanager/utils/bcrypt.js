const bcrypt = require('bcrypt');

const encryptanddecrypt ={

    async hashPwd(originalPWD){
        const hashedPwd = bcrypt.hashSync(originalPWD,10);
        return hashedPwd;
    },
    async matchPwd(originalPWD,hashedPwd){

        const matchedorNot = bcrypt.compareSync(originalPWD,hashedPwd);

        return matchedorNot;

    }
}

module.exports = encryptanddecrypt;