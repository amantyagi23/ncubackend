const {Router,request,response} = require('express');

const taskRoutes = Router();

taskRoutes.get('/getalltask',(request,response)=>{})

taskRoutes.post('/createtask')

taskRoutes.delete('/deletetask')

taskRoutes.put('/updatetask')


module.exports = taskRoutes;