const {Router,request,response} = require('express');
const {loginController,registerController} = require('../controllers/userController');

const userRoutes =Router();


userRoutes.post('/register',(request,response)=>{registerController(request,response)})
userRoutes.post('/login',(request,response)=>{loginController(request,response)})

// userRoutes.delete('/deletetask')

// userRoutes.put('/updatetask')


module.exports = userRoutes;