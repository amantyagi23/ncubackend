const express = require('express');

const taskRoutes = express.Router();

taskRoutes.get('/getalltask',)

taskRoutes.post('/createtask')

taskRoutes.delete('/deletetask')

taskRoutes.put('/updatetask')


module.exports = taskRoutes;